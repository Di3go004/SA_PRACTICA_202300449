# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.metrics.router import router as metrics_router
from app.reports.router import router as reports_router
from app.database import engine, Base
from app.scheduler.tasks import start_scheduler
import uvicorn
import os

# Crear tablas si no existen
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="YoUSAC Analytics Service",
    description="Microservicio de Analítica - Métricas y Reportes",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(metrics_router, prefix="/api/analytics/metrics", tags=["Metrics"])
app.include_router(reports_router, prefix="/api/analytics/reports", tags=["Reports"])

# Health check (RNF-017)
@app.get("/health")
def health():
    return {"status": "ok", "service": "analytics"}

# Iniciar scheduler de sincronización gRPC al arrancar
@app.on_event("startup")
async def startup_event():
    start_scheduler()
    print("✅ Analytics service iniciado")

if __name__ == "__main__":
    port = int(os.getenv("HTTP_PORT", 3002))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=False)
