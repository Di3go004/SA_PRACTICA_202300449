// internal/grpc/server/server.go
// Servidor gRPC que expone datos de reproducción al servicio de Analítica
package server

import (
	"context"
	"reproduction-service/internal/checkpoints"
	"reproduction-service/internal/ratings"
	pb "reproduction-service/proto"
)

// ReproduccionServer implementa la interfaz generada por protoc
type ReproduccionServer struct {
	pb.UnimplementedReproduccionServiceServer
	checkpointSvc *checkpoints.Service
	ratingSvc     *ratings.Service
}

func RegisterReproduccionServer(
	grpcServer interface{ RegisterService(interface{}, interface{}) },
	checkpointSvc *checkpoints.Service,
	ratingSvc *ratings.Service,
) {
	srv := &ReproduccionServer{
		checkpointSvc: checkpointSvc,
		ratingSvc:     ratingSvc,
	}
	pb.RegisterReproduccionServiceServer(grpcServer.(interface {
		RegisterService(*pb.ReproduccionService_ServiceDesc, interface{})
	}), srv)
}

// GetCheckpoint: devuelve el checkpoint de un usuario para un video
func (s *ReproduccionServer) GetCheckpoint(
	ctx context.Context,
	req *pb.CheckpointRequest,
) (*pb.CheckpointResponse, error) {
	userID  := int(req.GetUserId())
	videoID := int(req.GetVideoId())

	cp, err := s.checkpointSvc.GetCheckpoint(ctx, userID, videoID)
	if err != nil {
		return nil, err
	}

	if cp == nil {
		return &pb.CheckpointResponse{
			UserId:          req.GetUserId(),
			VideoId:         req.GetVideoId(),
			PositionSeconds: 0,
			ProgressPercent: 0,
			Completed:       false,
		}, nil
	}

	return &pb.CheckpointResponse{
		UserId:          req.GetUserId(),
		VideoId:         req.GetVideoId(),
		PositionSeconds: int32(cp.PositionSeconds),
		ProgressPercent: float32(cp.ProgressPercent),
		Completed:       cp.Completed,
	}, nil
}

// GetVideoStats: devuelve estadísticas de un video para Analítica
func (s *ReproduccionServer) GetVideoStats(
	ctx context.Context,
	req *pb.VideoStatsRequest,
) (*pb.VideoStatsResponse, error) {
	videoID := int(req.GetVideoId())

	stats, err := s.ratingSvc.GetVideoStats(ctx, videoID)
	if err != nil {
		return nil, err
	}

	return &pb.VideoStatsResponse{
		VideoId:               req.GetVideoId(),
		TotalViews:            int32(stats.TotalRatings),
		AverageProgress:       float32(stats.AverageStars),
		RecommendationPercent: float32(stats.RecommendationPercent),
	}, nil
}

// GetUserProgress: devuelve progreso de un usuario en un curso
func (s *ReproduccionServer) GetUserProgress(
	ctx context.Context,
	req *pb.UserProgressRequest,
) (*pb.UserProgressResponse, error) {
	// En implementación real vendría la lista de videoIDs del curso
	// desde el servicio de catálogo
	return &pb.UserProgressResponse{
		UserId:          req.GetUserId(),
		CourseId:        req.GetCourseId(),
		OverallProgress: 0,
		Videos:          []*pb.VideoProgress{},
	}, nil
}
